
import React, { useState, useEffect } from 'react';
import { ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react';

interface Slide {
  title: string;
  subtitle: string;
  image: string;
  color: string;
  category: string;
  buttonText: string;
}

const SLIDES: Slide[] = [
  {
    title: "Promo Ceria Si Kecil",
    subtitle: "Koleksi baju tidur Cloud Soft Kids diskon hingga 20% minggu ini!",
    image: "https://images.unsplash.com/photo-1515488442805-902422588c22?q=80&w=2000&auto=format&fit=crop",
    color: "from-blue-400/40",
    category: "Kids",
    buttonText: "Cek Koleksi Anak"
  },
  {
    title: "Elegansi Sutra Peony",
    subtitle: "Daster silk premium untuk kenyamanan mewah di dalam rumah.",
    image: "https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?q=80&w=2000&auto=format&fit=crop",
    color: "from-pink-500/40",
    category: "Women",
    buttonText: "Belanja Dress"
  },
  {
    title: "Esensial Pria Modern",
    subtitle: "Kaos katun 24s berkualitas tinggi untuk tampilan simpel nan berkelas.",
    image: "https://images.unsplash.com/photo-1562157873-818bc0726f68?q=80&w=2000&auto=format&fit=crop",
    color: "from-gray-500/40",
    category: "Men",
    buttonText: "Lihat Gaya Pria"
  }
];

interface HeroProps {
  onActionClick: (category: string) => void;
}

const Hero: React.FC<HeroProps> = ({ onActionClick }) => {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent(prev => (prev + 1) % SLIDES.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const next = () => setCurrent(prev => (prev + 1) % SLIDES.length);
  const prev = () => setCurrent(prev => (prev - 1 + SLIDES.length) % SLIDES.length);

  return (
    <div className="relative w-full h-[500px] md:h-[650px] overflow-hidden group">
      {SLIDES.map((slide, index) => (
        <div 
          key={index}
          className={`absolute inset-0 transition-all duration-1000 ease-in-out ${index === current ? 'opacity-100 scale-100' : 'opacity-0 scale-105'}`}
        >
          <img src={slide.image} alt={slide.title} className="w-full h-full object-cover" />
          <div className={`absolute inset-0 bg-gradient-to-r ${slide.color} to-black/60 flex items-center`}>
            <div className="max-w-7xl mx-auto px-6 w-full">
              <div className="max-w-2xl text-white space-y-6 animate-slideUp">
                <div className="inline-block px-4 py-1.5 bg-white/20 backdrop-blur-md rounded-full text-sm font-bold tracking-widest uppercase border border-white/30">
                  Exclusive Promo
                </div>
                <h1 className="text-5xl md:text-7xl font-serif font-bold drop-shadow-xl leading-tight">
                  {slide.title}
                </h1>
                <p className="text-xl md:text-2xl text-pink-50 font-medium drop-shadow-md max-w-lg">
                  {slide.subtitle}
                </p>
                <div className="pt-4">
                  <button 
                    onClick={() => onActionClick(slide.category)}
                    className="px-8 py-4 bg-white text-pink-600 rounded-full font-bold hover:bg-pink-50 transition-all shadow-xl hover:shadow-pink-500/20 flex items-center gap-3 w-fit text-lg group"
                  >
                    {slide.buttonText} 
                    <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      ))}

      {/* Navigation Controls */}
      <div className="absolute inset-x-0 bottom-8 flex justify-center gap-3 z-10">
        {SLIDES.map((_, i) => (
          <button 
            key={i}
            onClick={() => setCurrent(i)}
            className={`h-1.5 transition-all rounded-full ${i === current ? 'w-10 bg-white' : 'w-4 bg-white/40 hover:bg-white/60'}`}
          />
        ))}
      </div>

      <button onClick={prev} className="absolute left-6 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/20 rounded-full flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-all -translate-x-4 group-hover:translate-x-0">
        <ChevronLeft className="w-6 h-6" />
      </button>
      <button onClick={next} className="absolute right-6 top-1/2 -translate-y-1/2 w-12 h-12 bg-white/10 hover:bg-white/20 backdrop-blur-md border border-white/20 rounded-full flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-all translate-x-4 group-hover:translate-x-0">
        <ChevronRight className="w-6 h-6" />
      </button>
    </div>
  );
};

export default Hero;
