
import React, { useState } from 'react';
import { ChevronLeft, Share2, Heart, ShieldCheck, Truck, Info, MessageCircle, Star, ThumbsUp, ShoppingBag, PlayCircle } from 'lucide-react';
import { Product } from '../types';
import CheckoutModal from './CheckoutModal';

interface ProductDetailProps {
  product: Product;
  onBack: () => void;
}

const ProductDetail: React.FC<ProductDetailProps> = ({ product, onBack }) => {
  const [selectedSize, setSelectedSize] = useState(product.sizes[0]);
  const [selectedColor, setSelectedColor] = useState(product.colors[0]);
  const [isShowingVideo, setIsShowingVideo] = useState(false);
  const [activeReviewFilter, setActiveReviewFilter] = useState('Semua');
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);

  // Determine which content to show based on state
  const displayImage = product.colorImages?.[selectedColor] || product.image;

  const formattedPrice = new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    maximumFractionDigits: 0
  }).format(product.price);

  const handleColorSelect = (color: string) => {
    setSelectedColor(color);
    setIsShowingVideo(false);
  };

  const handleWhatsAppClick = () => {
    const phoneNumber = "6281935593614";
    const message = `Halo GelisLux, saya tertarik untuk memesan produk ini:

*Produk:* ${product.name}
*Varian Warna:* ${selectedColor}
*Ukuran:* ${selectedSize}
*Harga:* ${formattedPrice}

Mohon informasi ketersediaan stok dan cara pembayarannya. Terima kasih!`;

    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodedMessage}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <div className="animate-fadeIn space-y-12">
      <button 
        onClick={onBack}
        className="flex items-center gap-2 text-gray-500 hover:text-pink-600 font-medium transition-colors group"
      >
        <ChevronLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
        Kembali ke Katalog
      </button>

      {/* Product Main Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
        {/* Left: Images/Video Gallery */}
        <div className="lg:col-span-7 space-y-4">
          <div className="rounded-3xl overflow-hidden aspect-[4/5] bg-black shadow-sm border border-pink-50 relative">
            {isShowingVideo && product.video ? (
              <video 
                src={product.video} 
                className="w-full h-full object-contain" 
                controls 
                autoPlay 
                loop
              />
            ) : (
              <img 
                key={displayImage} // Force re-animation on image change
                src={displayImage} 
                alt={product.name} 
                className="w-full h-full object-cover animate-fadeIn"
              />
            )}
            
            {/* Tag Video in main image if exists */}
            {product.video && !isShowingVideo && (
              <button 
                onClick={() => setIsShowingVideo(true)}
                className="absolute inset-0 m-auto w-16 h-16 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center hover:scale-110 transition-transform group"
              >
                <PlayCircle className="w-10 h-10 text-white fill-white/20 group-hover:fill-pink-500 group-hover:text-pink-500 transition-colors" />
              </button>
            )}
          </div>
          
          <div className="grid grid-cols-5 gap-3">
            {/* Gallery thumbnails */}
            {product.colors.map((color) => (
              product.colorImages?.[color] && (
                <div 
                  key={color}
                  onClick={() => handleColorSelect(color)}
                  className={`aspect-square rounded-xl overflow-hidden cursor-pointer border-2 transition-all ${selectedColor === color && !isShowingVideo ? 'border-pink-500 shadow-md shadow-pink-100 scale-105' : 'border-transparent hover:border-pink-200 opacity-70 hover:opacity-100'}`}
                >
                  <img 
                    src={product.colorImages[color]} 
                    alt={color} 
                    className="w-full h-full object-cover"
                  />
                </div>
              )
            ))}

            {/* Video Thumbnail Button */}
            {product.video && (
              <div 
                onClick={() => setIsShowingVideo(true)}
                className={`aspect-square rounded-xl overflow-hidden cursor-pointer border-2 transition-all relative group ${isShowingVideo ? 'border-pink-500 shadow-md shadow-pink-100 scale-105' : 'border-transparent hover:border-pink-200 opacity-70 hover:opacity-100'}`}
              >
                <div className="absolute inset-0 bg-gray-900 flex items-center justify-center">
                  <PlayCircle className={`w-8 h-8 ${isShowingVideo ? 'text-pink-500' : 'text-white'}`} />
                  <span className="absolute bottom-1 text-[8px] font-bold text-white uppercase tracking-tighter">Review Video</span>
                </div>
                {/* Background thumb from first image */}
                <img 
                  src={product.image} 
                  className="w-full h-full object-cover opacity-20"
                  alt="Video Review"
                />
              </div>
            )}
          </div>
        </div>

        {/* Right: Details */}
        <div className="lg:col-span-5 space-y-8">
          <div>
            <div className="flex justify-between items-start mb-2">
              <span className="px-3 py-1 bg-pink-100 text-pink-600 text-xs font-bold rounded-full uppercase tracking-wider">
                {product.category}
              </span>
              <div className="flex gap-2">
                <button className="p-2.5 bg-gray-100 hover:bg-pink-50 hover:text-pink-600 rounded-full transition-all">
                  <Share2 className="w-5 h-5" />
                </button>
                <button className="p-2.5 bg-gray-100 hover:bg-pink-50 hover:text-pink-600 rounded-full transition-all">
                  <Heart className="w-5 h-5" />
                </button>
              </div>
            </div>
            <h1 className="text-4xl font-serif font-bold text-gray-900 mb-2">{product.name}</h1>
            
            <div className="flex items-center gap-4 mb-4">
              <div className="flex items-center gap-1 border-r border-gray-200 pr-4">
                <span className="text-pink-600 font-bold underline text-lg">{product.rating}</span>
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className={`w-4 h-4 ${i < Math.floor(product.rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-200'}`} />
                  ))}
                </div>
              </div>
              <div className="text-gray-600 border-r border-gray-200 pr-4">
                <span className="font-bold text-gray-900 underline">{product.reviews.length}</span> <span className="text-sm">Penilaian</span>
              </div>
              <div className="text-gray-600">
                <span className="font-bold text-gray-900">{product.soldCount}</span> <span className="text-sm">Terjual</span>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <span className="text-3xl font-bold text-gray-900">{formattedPrice}</span>
              {product.oldPrice && (
                <span className="text-xl text-gray-400 line-through">
                   {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(product.oldPrice)}
                </span>
              )}
            </div>
          </div>

          {/* Shopee Style Color Selection Section */}
          <div className="space-y-4">
            <h3 className="font-bold text-gray-800">Pilih Warna: <span className="text-pink-600">{selectedColor}</span></h3>
            <div className="flex flex-wrap gap-3">
              {product.colors.map(color => (
                <button 
                  key={color}
                  onClick={() => handleColorSelect(color)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border-2 transition-all ${selectedColor === color && !isShowingVideo ? 'border-pink-500 bg-pink-50' : 'border-gray-100 hover:border-pink-200 bg-white'}`}
                >
                  {product.colorImages?.[color] ? (
                    <img 
                      src={product.colorImages[color]} 
                      className="w-8 h-8 rounded object-cover" 
                      alt={color} 
                    />
                  ) : (
                    <div 
                      className="w-8 h-8 rounded border"
                      style={{ 
                        backgroundColor: 
                          color.toLowerCase().includes('white') ? '#ffffff' : 
                          color.toLowerCase().includes('pink') ? '#ffdae9' : 
                          color.toLowerCase().includes('green') ? '#d4f1f4' : 
                          color.toLowerCase().includes('yellow') ? '#fff9c4' : 
                          color.toLowerCase().includes('black') ? '#000000' : 
                          color.toLowerCase().includes('navy') ? '#000080' : 
                          color.toLowerCase().includes('blue') ? '#add8e6' : 
                          '#e5e7eb' 
                      }}
                    />
                  )}
                  <span className={`text-xs font-bold ${selectedColor === color && !isShowingVideo ? 'text-pink-600' : 'text-gray-600'}`}>
                    {color}
                  </span>
                </button>
              ))}
              
              {/* Added Video Option here as well for quick access in color picker */}
              {product.video && (
                <button 
                  onClick={() => setIsShowingVideo(true)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border-2 transition-all ${isShowingVideo ? 'border-pink-500 bg-pink-50' : 'border-gray-100 hover:border-pink-200 bg-white'}`}
                >
                  <PlayCircle className={`w-8 h-8 ${isShowingVideo ? 'text-pink-500' : 'text-gray-400'}`} />
                  <span className={`text-xs font-bold ${isShowingVideo ? 'text-pink-600' : 'text-gray-600'}`}>
                    Review Video
                  </span>
                </button>
              )}
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-gray-800">Pilih Ukuran</h3>
              <button className="text-sm text-pink-600 font-medium hover:underline flex items-center gap-1">
                <Info className="w-4 h-4" /> Size Guide
              </button>
            </div>
            <div className="flex flex-wrap gap-3">
              {product.sizes.map(size => (
                <button 
                  key={size}
                  onClick={() => setSelectedSize(size)}
                  className={`px-6 py-2.5 rounded-xl font-bold transition-all border ${selectedSize === size ? 'bg-gray-900 text-white border-gray-900 shadow-lg' : 'bg-white text-gray-600 border-gray-200 hover:border-pink-300'}`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>

          <div className="flex flex-col gap-4">
            <button 
              onClick={() => setIsCheckoutOpen(true)}
              className="w-full py-5 bg-gray-900 text-white rounded-2xl font-bold text-xl flex items-center justify-center gap-3 shadow-xl hover:bg-black transition-all active:scale-[0.98]"
            >
              <ShoppingBag className="w-6 h-6" />
              Beli Sekarang
            </button>
            <button 
              onClick={handleWhatsAppClick}
              className="w-full py-5 bg-[#25D366] text-white rounded-2xl font-bold text-xl flex items-center justify-center gap-3 shadow-xl hover:bg-[#1ebc5a] transition-all active:scale-[0.98] animate-pulse-wa"
            >
              <MessageCircle className="w-6 h-6 fill-current" />
              Pesan via WhatsApp
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t border-gray-100 pt-8">
            <div className="flex items-center gap-3 p-3 bg-pink-50/50 rounded-2xl">
              <ShieldCheck className="w-6 h-6 text-pink-600" />
              <p className="text-xs font-bold text-gray-800 uppercase">100% Produk Original</p>
            </div>
            <div className="flex items-center gap-3 p-3 bg-rose-50/50 rounded-2xl">
              <Truck className="w-6 h-6 text-rose-600" />
              <p className="text-xs font-bold text-gray-800 uppercase">Bebas Pengembalian</p>
            </div>
          </div>

          <div className="prose prose-pink max-w-none">
            <h3 className="text-gray-900 font-bold mb-2">Spesifikasi & Deskripsi</h3>
            <p className="text-gray-600 text-sm leading-relaxed whitespace-pre-line border-l-4 border-pink-200 pl-4 bg-gray-50/50 py-2">
              {product.description}
            </p>
          </div>
        </div>
      </div>

      {/* Reviews Section */}
      <section className="bg-white rounded-3xl p-8 border border-gray-100 shadow-sm space-y-8">
        <h2 className="text-2xl font-serif font-bold text-gray-900">PENILAIAN PRODUK</h2>
        
        <div className="bg-pink-50/30 p-8 rounded-2xl border border-pink-100 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center md:text-left">
            <div className="flex items-baseline justify-center md:justify-start gap-1">
              <span className="text-4xl font-bold text-pink-600">{product.rating}</span>
              <span className="text-gray-500 font-medium">dari 5</span>
            </div>
            <div className="flex justify-center md:justify-start mt-2">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className={`w-6 h-6 ${i < Math.floor(product.rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-200'}`} />
              ))}
            </div>
          </div>
          
          <div className="md:col-span-2 flex flex-wrap gap-2 items-center justify-center md:justify-start">
            {['Semua', '5 Bintang', '4 Bintang', '3 Bintang', 'Dengan Foto', 'Dengan Komentar'].map(filter => (
              <button 
                key={filter}
                onClick={() => setActiveReviewFilter(filter)}
                className={`px-5 py-2 rounded-lg text-sm font-medium border transition-all ${activeReviewFilter === filter ? 'bg-white border-pink-500 text-pink-600 shadow-sm' : 'bg-white border-gray-200 text-gray-600 hover:border-pink-200'}`}
              >
                {filter}
              </button>
            ))}
          </div>
        </div>

        <div className="divide-y divide-gray-100">
          {product.reviews.map((review) => (
            <div key={review.id} className="py-8 flex gap-4">
              <div className="shrink-0">
                <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center text-gray-400 border border-gray-200">
                   {review.avatar ? <img src={review.avatar} className="w-full h-full rounded-full" /> : <Info className="w-6 h-6" />}
                </div>
              </div>
              <div className="flex-grow space-y-2">
                <div>
                  <h4 className="text-sm font-bold text-gray-900">{review.userName}</h4>
                  <div className="flex gap-0.5 mt-0.5">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className={`w-3 h-3 ${i < review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-200'}`} />
                    ))}
                  </div>
                </div>
                
                <div className="text-xs text-gray-400 flex gap-3">
                  <span>Varian: {review.variant || 'Default'}</span>
                  <span className="text-gray-200">|</span>
                  <span>{review.date}</span>
                </div>

                <p className="text-sm text-gray-700 leading-relaxed py-1">
                  {review.comment}
                </p>

                <div className="flex items-center gap-4 pt-2">
                   <button className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-pink-600 transition-colors">
                     <ThumbsUp className="w-3.5 h-3.5" /> Membantu (0)
                   </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center pt-4">
           <button className="px-8 py-3 border border-pink-200 text-pink-600 font-bold rounded-xl hover:bg-pink-50 transition-all">
             Tampilkan Lebih Banyak
           </button>
        </div>
      </section>

      <CheckoutModal 
        product={product} 
        size={selectedSize} 
        isOpen={isCheckoutOpen} 
        onClose={() => setIsCheckoutOpen(false)} 
      />
    </div>
  );
};

export default ProductDetail;
