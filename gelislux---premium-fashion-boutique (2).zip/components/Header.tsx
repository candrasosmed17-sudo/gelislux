
import React from 'react';
import { Search, Heart, ShoppingBag, User, Menu } from 'lucide-react';

interface HeaderProps {
  onHomeClick: () => void;
  onSearch: (query: string) => void;
  onCategorySelect: (category: string | null) => void;
  activeCategory: string | null;
}

const Header: React.FC<HeaderProps> = ({ onHomeClick, onSearch, onCategorySelect, activeCategory }) => {
  const categories = ['Men', 'Women', 'Kids', 'Accessories'];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-pink-100">
      <div className="max-w-7xl mx-auto px-4 h-20 flex items-center justify-between gap-4">
        <div className="flex items-center gap-6">
          <button 
            onClick={onHomeClick}
            className="text-3xl font-serif font-bold bg-gradient-to-r from-pink-600 to-rose-500 bg-clip-text text-transparent"
          >
            GelisLux
          </button>
          
          <nav className="hidden lg:flex items-center gap-8 text-sm font-medium text-gray-600">
            {categories.map((cat) => (
              <button 
                key={cat}
                onClick={() => onCategorySelect(cat)}
                className={`transition-colors hover:text-pink-500 ${activeCategory === cat ? 'text-pink-600 font-bold border-b-2 border-pink-600' : ''}`}
              >
                {cat}
              </button>
            ))}
            <button className="text-rose-600 font-bold">Sale</button>
          </nav>
        </div>

        <div className="flex-grow max-w-xl hidden md:block">
          <div className="relative group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400 group-focus-within:text-pink-500 transition-colors" />
            <input 
              type="text" 
              placeholder="Search for elegant styles..."
              onChange={(e) => onSearch(e.target.value)}
              className="w-full pl-12 pr-4 py-2.5 bg-gray-100/50 border border-transparent focus:border-pink-200 focus:bg-white rounded-full outline-none transition-all"
            />
          </div>
        </div>

        <div className="flex items-center gap-2 sm:gap-4">
          <button className="p-2 text-gray-600 hover:text-pink-500 hover:bg-pink-50 rounded-full transition-all">
            <Heart className="w-6 h-6" />
          </button>
          <button className="p-2 text-gray-600 hover:text-pink-500 hover:bg-pink-50 rounded-full transition-all relative">
            <ShoppingBag className="w-6 h-6" />
            <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-pink-500 text-white text-[10px] flex items-center justify-center rounded-full">0</span>
          </button>
          <button className="flex items-center gap-2 p-1.5 border border-pink-100 rounded-full hover:bg-pink-50 transition-all">
            <div className="w-8 h-8 bg-pink-200 rounded-full flex items-center justify-center text-pink-700 font-bold text-xs uppercase">
              GL
            </div>
            <User className="w-5 h-5 text-gray-500 hidden sm:block" />
          </button>
          <button className="lg:hidden p-2 text-gray-600 hover:bg-gray-100 rounded-full">
            <Menu className="w-6 h-6" />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
