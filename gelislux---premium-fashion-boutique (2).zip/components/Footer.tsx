
import React from 'react';
import { Instagram, Twitter, Facebook, ExternalLink, MessageCircle } from 'lucide-react';

const Footer: React.FC = () => {
  const whatsappNumber = "6281935593614";
  const waLink = `https://wa.me/${whatsappNumber}?text=Halo%20GelisLux%2C%20saya%20ingin%20bertanya%20mengenai%20produk...`;

  return (
    <footer className="bg-gray-900 text-gray-300 py-16">
      <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
        <div className="space-y-6">
          <h2 className="text-3xl font-serif font-bold text-white tracking-tight">GelisLux</h2>
          <p className="text-sm leading-relaxed text-gray-400">
            Membangun rasa percaya diri melalui busana berkualitas dengan palet warna lembut. Koleksi terpilih untuk gaya hidup modern Anda.
          </p>
          <div className="flex gap-4">
            <a 
              href="https://www.instagram.com/bana_naco/" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="p-2 rounded-lg bg-gray-800 hover:bg-pink-600 transition-colors"
            >
              <Instagram className="w-5 h-5 text-white" />
            </a>
            <button className="p-2 rounded-lg bg-gray-800 hover:bg-pink-600 transition-colors">
              <Twitter className="w-5 h-5 text-white" />
            </button>
            <button className="p-2 rounded-lg bg-gray-800 hover:bg-pink-600 transition-colors">
              <Facebook className="w-5 h-5 text-white" />
            </button>
          </div>
        </div>

        <div className="space-y-6">
          <h3 className="text-white font-bold uppercase tracking-widest text-xs">Menu Cepat</h3>
          <ul className="space-y-4 text-sm font-medium">
            <li><button className="hover:text-pink-400 transition-colors">Koleksi Kemeja</button></li>
            <li><button className="hover:text-pink-400 transition-colors">Celana & Jeans</button></li>
            <li><button className="hover:text-pink-400 transition-colors">Best Sellers</button></li>
            <li><button className="hover:text-pink-400 transition-colors">Cara Order</button></li>
          </ul>
        </div>

        <div className="space-y-6">
          <h3 className="text-white font-bold uppercase tracking-widest text-xs">Bantuan</h3>
          <ul className="space-y-4 text-sm font-medium">
            <li><button className="hover:text-pink-400 transition-colors">Panduan Ukuran</button></li>
            <li><button className="hover:text-pink-400 transition-colors">Kebijakan Pengembalian</button></li>
            <li>
              <a 
                href={waLink}
                target="_blank"
                rel="noopener noreferrer"
                className="hover:text-pink-400 transition-colors flex items-center gap-2"
              >
                Hubungi Admin <MessageCircle className="w-3 h-3" />
              </a>
            </li>
            <li><button className="hover:text-pink-400 transition-colors">FAQ</button></li>
          </ul>
        </div>

        <div className="space-y-6">
          <h3 className="text-white font-bold uppercase tracking-widest text-xs">Follow Us</h3>
          <div className="flex flex-col gap-4">
            <a 
              href="https://www.instagram.com/bana_naco/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="group relative inline-block p-4 bg-white rounded-2xl shadow-xl hover:scale-105 transition-transform w-fit"
            >
              <img 
                src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=https://www.instagram.com/bana_naco/" 
                alt="Instagram QR Code" 
                className="w-28 h-28"
              />
              <div className="absolute inset-0 bg-pink-500/10 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded-2xl">
                <div className="bg-white/90 p-2 rounded-full shadow-lg">
                  <ExternalLink className="w-5 h-5 text-pink-600" />
                </div>
              </div>
            </a>
            <div>
              <p className="text-sm font-bold text-pink-400">@BANA_NACO</p>
              <p className="text-[10px] text-gray-500 mt-1 uppercase tracking-tighter">Scan untuk profil Instagram</p>
            </div>
          </div>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 mt-16 pt-8 border-t border-gray-800 flex flex-col md:flex-row justify-between items-center gap-4 text-xs font-medium text-gray-500 uppercase tracking-widest">
        <p>&copy; 2024 GelisLux Boutique. Crafted for your beauty.</p>
        <div className="flex gap-8">
          <span>Trusted Seller</span>
          <span>Fast Delivery</span>
          <span>Premium Material</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
