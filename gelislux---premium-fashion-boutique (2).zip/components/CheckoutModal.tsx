
import React, { useState } from 'react';
import { X, CreditCard, Wallet, CheckCircle2, Loader2, ArrowRight } from 'lucide-react';
import { Product } from '../types';
import { PAYMENT_METHODS } from '../constants';

interface CheckoutModalProps {
  product: Product;
  size: string;
  isOpen: boolean;
  onClose: () => void;
}

const CheckoutModal: React.FC<CheckoutModalProps> = ({ product, size, isOpen, onClose }) => {
  const [step, setStep] = useState(1);
  const [selectedMethod, setSelectedMethod] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleNext = () => {
    if (step === 1) setStep(2);
    else if (step === 2) {
      setStep(3);
      setTimeout(() => setStep(4), 2000);
    }
  };

  const formattedPrice = new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    maximumFractionDigits: 0
  }).format(product.price);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center px-4">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      
      <div className="relative bg-white w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden animate-slideUp">
        {/* Header */}
        <div className="px-6 py-4 border-b border-gray-100 flex justify-between items-center bg-white">
          <h3 className="font-bold text-gray-900">Checkout Aman</h3>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {step === 1 && (
            <div className="space-y-6">
              <div className="flex gap-4 p-4 bg-gray-50 rounded-2xl">
                <img src={product.image} className="w-20 h-24 object-cover rounded-xl" alt="" />
                <div>
                  <h4 className="font-bold text-gray-900">{product.name}</h4>
                  <p className="text-sm text-gray-500">Ukuran: <span className="font-bold text-pink-600">{size}</span></p>
                  <p className="font-bold text-lg mt-1">{formattedPrice}</p>
                </div>
              </div>

              <div className="space-y-3">
                <h5 className="text-xs font-bold text-gray-400 uppercase tracking-widest">Pilih Metode Pembayaran</h5>
                
                <div className="grid grid-cols-1 gap-3">
                  <div className="border border-gray-200 rounded-2xl p-4">
                    <div className="flex items-center gap-2 mb-3 text-sm font-bold text-gray-700">
                      <Wallet className="w-4 h-4 text-pink-500" /> E-Wallet
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      {PAYMENT_METHODS.ewallet.map(m => (
                        <button 
                          key={m.id}
                          onClick={() => setSelectedMethod(m.id)}
                          className={`p-3 border rounded-xl flex items-center justify-center gap-2 transition-all ${selectedMethod === m.id ? 'border-pink-500 bg-pink-50' : 'border-gray-100 hover:border-pink-200'}`}
                        >
                          <span className="text-xs font-bold">{m.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="border border-gray-200 rounded-2xl p-4">
                    <div className="flex items-center gap-2 mb-3 text-sm font-bold text-gray-700">
                      <CreditCard className="w-4 h-4 text-pink-500" /> Virtual Account Bank
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      {PAYMENT_METHODS.bank.map(m => (
                        <button 
                          key={m.id}
                          onClick={() => setSelectedMethod(m.id)}
                          className={`p-3 border rounded-xl flex items-center justify-center gap-2 transition-all ${selectedMethod === m.id ? 'border-pink-500 bg-pink-50' : 'border-gray-100 hover:border-pink-200'}`}
                        >
                          <span className="text-xs font-bold">{m.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <button 
                disabled={!selectedMethod}
                onClick={handleNext}
                className={`w-full py-4 rounded-2xl font-bold text-lg flex items-center justify-center gap-2 transition-all ${selectedMethod ? 'bg-gray-900 text-white shadow-xl hover:bg-black' : 'bg-gray-100 text-gray-400 cursor-not-allowed'}`}
              >
                Lanjutkan Ke Pembayaran <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          )}

          {step === 3 && (
            <div className="py-20 flex flex-col items-center justify-center space-y-4">
              <Loader2 className="w-12 h-12 text-pink-500 animate-spin" />
              <p className="font-bold text-gray-600">Memproses transaksi Anda...</p>
            </div>
          )}

          {step === 4 && (
            <div className="py-10 text-center space-y-6">
              <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle2 className="w-12 h-12" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-gray-900">Pesanan Berhasil!</h3>
                <p className="text-gray-500 mt-2">Terima kasih telah berbelanja di GelisLux. Detail pesanan telah dikirim ke email Anda.</p>
              </div>
              <button 
                onClick={onClose}
                className="w-full py-4 bg-gray-900 text-white rounded-2xl font-bold hover:bg-black transition-all"
              >
                Kembali ke Toko
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CheckoutModal;
