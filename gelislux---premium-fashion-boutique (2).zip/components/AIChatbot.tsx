
import React from 'react';

const AIChatbot: React.FC = () => {
  // Use React.createElement to avoid TypeScript errors with custom elements without needing global JSX overrides
  // that can cause standard HTML elements to become unrecognized in the project.
  return (
    <div className="fixed bottom-6 right-6 z-[9999]">
      {React.createElement('elevenlabs-convai', { 
        'agent-id': "agent_5301kesv44acfv88cd1swrj2k3az" 
      })}
    </div>
  );
};

export default AIChatbot;
