
import React from 'react';
import { Star } from 'lucide-react';
import { TESTIMONIALS } from '../constants';

const Testimonials: React.FC = () => {
  return (
    <section className="bg-white py-20 border-y border-pink-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl font-serif font-bold text-gray-900">What Our Clients Say</h2>
          <p className="text-gray-500 max-w-2xl mx-auto">
            GelisLux is more than a store. It's a community of fashion enthusiasts who value elegance and quality.
          </p>
        </div>

        <div className="columns-1 md:columns-2 lg:columns-3 gap-6 space-y-6">
          {TESTIMONIALS.map((t) => (
            <div 
              key={t.id} 
              className="break-inside-avoid bg-white border border-gray-100 rounded-3xl p-6 shadow-sm hover:shadow-md transition-shadow"
            >
              <div className="flex items-center gap-4 mb-4">
                <img src={t.avatar} alt={t.author} className="w-12 h-12 rounded-full border-2 border-pink-100" />
                <div>
                  <h4 className="font-bold text-gray-900 leading-tight">{t.author}</h4>
                  <p className="text-xs text-pink-500 font-medium">{t.role}</p>
                </div>
              </div>
              <p className="text-gray-600 text-sm leading-relaxed mb-4 italic">
                "{t.content}"
              </p>
              <div className="flex gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star 
                    key={i} 
                    className={`w-4 h-4 ${i < t.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-200'}`} 
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
