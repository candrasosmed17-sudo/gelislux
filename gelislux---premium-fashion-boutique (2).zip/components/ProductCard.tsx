
import React from 'react';
import { Heart, Star } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onClick: (product: Product) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onClick }) => {
  return (
    <div 
      className="group cursor-pointer bg-white rounded-2xl overflow-hidden border border-transparent hover:border-pink-100 hover:shadow-xl transition-all duration-300"
      onClick={() => onClick(product)}
    >
      <div className="relative aspect-[4/5] overflow-hidden">
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        <div className="absolute top-3 right-3">
          <button 
            className="w-10 h-10 bg-white/80 backdrop-blur-sm rounded-full flex items-center justify-center text-gray-600 hover:text-pink-500 hover:bg-white transition-all shadow-md"
            onClick={(e) => {
              e.stopPropagation();
            }}
          >
            <Heart className="w-5 h-5" />
          </button>
        </div>
        {product.oldPrice && (
          <div className="absolute bottom-3 left-3 px-3 py-1 bg-rose-500 text-white text-xs font-bold rounded-full">
            Sale
          </div>
        )}
      </div>
      
      <div className="p-4 space-y-1">
        <div className="flex justify-between items-start">
          <h3 className="text-gray-900 font-semibold group-hover:text-pink-600 transition-colors truncate pr-2">
            {product.name}
          </h3>
        </div>
        <div className="flex items-center gap-2 pt-1">
          <span className="text-lg font-bold text-gray-900">
            {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(product.price)}
          </span>
          {product.oldPrice && (
            <span className="text-sm text-gray-400 line-through">
              {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(product.oldPrice)}
            </span>
          )}
        </div>
        
        <div className="flex items-center gap-2 pt-1">
          <div className="flex items-center">
            <Star className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" />
            <span className="text-xs font-bold ml-1 text-gray-700">{product.rating}</span>
          </div>
          <span className="text-gray-300">|</span>
          <span className="text-[11px] text-gray-500 font-medium">Terjual {product.soldCount > 1000 ? (product.soldCount / 1000).toFixed(1) + 'rb+' : product.soldCount}</span>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
